﻿using InventoryMangementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjectDotNet_IMS.Controllers
{
   public class AdminController
    {
        public static void UpdateUser()
        {
            var ctx = new InventoryContext();
            User data = new User();
            Console.Write("enter  userid: ");
            data.UserID = Convert.ToInt32(Console.ReadLine());


            var finddata = ctx.Users.First(x => x.UserID == data.UserID);

            Console.Write("enter  username: ");
            data.Username = Console.ReadLine();
            finddata.Username = data.Username;

            Console.WriteLine(ctx.SaveChanges());
        }
        public static void deleteuser()
        {
            var ctx = new InventoryContext();
            Console.Write("enter  id: ");
            User data = new User();
            data.UserID = Convert.ToInt32(Console.ReadLine());
            var finddata = ctx.Users.First(x => x.UserID == data.UserID);
            ctx.Users.Remove(finddata);
            Console.WriteLine(ctx.SaveChanges());
        }

        public static void AddUser()
        {
            string name, email, username, password;
            string role;
            Console.Write("Enter Name :");
            name = Console.ReadLine();
            Console.Write("Enter Email:");
            email = Console.ReadLine();
            Console.Write("Enter username :");
            username = Console.ReadLine();
            Console.Write("Enter Password:");
            password = Console.ReadLine();
            Console.Write("Enter role:");
            role = Console.ReadLine();

            using (var add = new InventoryContext())
            {
                User U = new User();
                U.Name = name.ToString();
                U.Email = email.ToString();
                U.Username = username.ToString();
                U.Password = password.ToString();
                U.Role = role.ToString();
                add.Add(U);
                add.SaveChanges();
                Console.WriteLine("user added succesfully");

            }
        }
        public static void FetchUser()
        {
            var ctx = new InventoryContext();
            User user = new User();
            Console.WriteLine("Enter th role: ");
            user.Role = Console.ReadLine();

            foreach (var item in ctx.Users)
            {
                Console.WriteLine(item.UserID + " " + item.Name + " " + item.Username + " " + item.Email + " " + item.Password + " " + item.Role);
            }
        }
    }
}
