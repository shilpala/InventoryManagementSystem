﻿using InventoryMangementSystem.Models;
using MiniProjectDotNet_IMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjectDotNet_IMS.Controllers
{
    public class AirpodController
    {
        public static void AddairpodData()
        {

            string name, color;
            decimal price;
            int quantity, userid;
            Console.Write("Enter Name :");
            name = Console.ReadLine();
            Console.Write("Enter color:");
            color = Console.ReadLine();
            Console.Write("Enter price:");
            string readLine = Console.ReadLine();
            price = decimal.Parse(readLine);
            Console.Write("Enter avaialable quantity:");
            string readLine2 = Console.ReadLine();
            quantity = int.Parse(readLine2);
            Console.Write("Enter UserID:");
            string readLine3 = Console.ReadLine();
            userid = int.Parse(readLine3);


            using (var add = new InventoryContext())
            {
                Airpod data = new Airpod();
                data.Name = name.ToString();
                data.Color = color.ToString();
                data.Price = price;
                data.AvailableQuantity = quantity;
                data.UserID = userid;
                add.Add(data);
                add.SaveChanges();
                Console.WriteLine("Airpod data added succesfully");

            }
        }

        public static void UpdateairpodData()
        {
            var ctx = new InventoryContext();
            Airpod data = new Airpod();
            Console.Write("enter Airpod id: ");
            data.PodID = Convert.ToInt32(Console.ReadLine());


            var finddata = ctx.airpods.First(x => x.PodID == data.PodID);

            Console.Write("enter available quantity: ");
            data.AvailableQuantity = Convert.ToInt32(Console.ReadLine());
            finddata.AvailableQuantity = data.AvailableQuantity;

            Console.WriteLine(ctx.SaveChanges());
        }
        public static void deleteairpoddata()
        {
            var ctx = new InventoryContext();
            Console.Write("enter  Airpod id: ");
            Airpod data = new Airpod();
            data.PodID = Convert.ToInt32(Console.ReadLine());

            var finddata = ctx.airpods.First(x => x.PodID == data.PodID);
            ctx.airpods.Remove(finddata);
            Console.WriteLine(ctx.SaveChanges());
        }
        public static void Fetchairpoddata()
        {
            var ctx = new InventoryContext();
            Airpod data = new Airpod();
            Console.WriteLine("Enter name : ");
            data.Name = Console.ReadLine();

            foreach (var item in ctx.airpods)
            {
                Console.WriteLine(item.PodID + "|" + item.Name + "|" + item.Price + "|" + item.Color + "|" + item.AvailableQuantity);
            }
        }

    }
}
