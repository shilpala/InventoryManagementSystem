﻿using InventoryMangementSystem.Models;
using MiniProjectDotNet_IMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjectDotNet_IMS.Controllers
{
    public class AppleIpadController
    {
        public static void AddappleipadData()
        {

            string name;
            decimal price;
            float screensize;
            int quantity, userid;
            Console.Write("Enter Name :");
            name = Console.ReadLine();
            Console.Write("Enter price:");
            string readLine = Console.ReadLine();
            price = decimal.Parse(readLine);
            Console.Write("Enter screensize:");
            string readLine1 = Console.ReadLine();
            screensize = float.Parse(readLine1);
            Console.Write("Enter avaialable quantity:");
            string readLine2 = Console.ReadLine();
            quantity = int.Parse(readLine2);
            Console.Write("Enter UserID:");
            string readLine3 = Console.ReadLine();
            userid = int.Parse(readLine3);


            using (var add = new InventoryContext())
            {
                AppleIPad data = new AppleIPad();
                data.Name = name.ToString();
                data.Price = price;
                data.AvailableQuantity = quantity;
                data.ScreenSize = screensize;
                data.UserID = userid;
                add.Add(data);
                add.SaveChanges();
                Console.WriteLine("Appleipad data added succesfully");

            }
        }

        public static void UpdateappleipadData()
        {
            var ctx = new InventoryContext();
            AppleIPad data = new AppleIPad();
            Console.Write("enter AppleIpad id: ");
            data.AppleId = Convert.ToInt32(Console.ReadLine());


            var finddata = ctx.appleipads.First(x => x.AppleId == data.AppleId);

            Console.Write("enter available quantity: ");
            data.AvailableQuantity = Convert.ToInt32(Console.ReadLine());
            finddata.AvailableQuantity = data.AvailableQuantity;

            Console.WriteLine(ctx.SaveChanges());
        }
        public static void deleteappleipaddata()
        {
            var ctx = new InventoryContext();
            Console.Write("enter AppleIpad id: ");
            AppleIPad data = new AppleIPad();
            data.AppleId = Convert.ToInt32(Console.ReadLine());
            var finddata = ctx.appleipads.First(x => x.AppleId == data.AppleId);
            ctx.appleipads.Remove(finddata);
            Console.WriteLine(ctx.SaveChanges());
        }
        public static void Fetchappleipaddata()
        {
            var ctx = new InventoryContext();
            AppleIPad data = new AppleIPad();
            Console.WriteLine("Enter name : ");
            data.Name = Console.ReadLine();

            foreach (var item in ctx.appleipads)
            {
                Console.WriteLine(item.AppleId + "|" + item.Name + "|" + item.Price + "|" + item.AvailableQuantity + "|" + item.ScreenSize);
            }
        }
    }
}