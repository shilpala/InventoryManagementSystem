﻿using InventoryMangementSystem.Models;
using MiniProjectDotNet_IMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjectDotNet_IMS.Controllers
{
    public class IphoneController
    {
        public static void AddiphoneData()
        {

            string name, color;
            decimal price;
            float screensize;
            int quantity, userid;
            Console.Write("Enter Name :");
            name = Console.ReadLine();
            Console.Write("Enter color:");
            color = Console.ReadLine();
            Console.Write("Enter price:");
            string readLine = Console.ReadLine();
            price = decimal.Parse(readLine);
            Console.Write("Enter screensize:");
            string readLine1 = Console.ReadLine();
            screensize = float.Parse(readLine1);
            Console.Write("Enter avaialable quantity:");
            string readLine2 = Console.ReadLine();
            quantity = int.Parse(readLine2);
            Console.Write("Enter UserID:");
            string readLine3 = Console.ReadLine();
            userid = int.Parse(readLine3);


            using (var add = new InventoryContext())
            {
                Iphone iphone = new Iphone();
                iphone.Name = name.ToString();
                iphone.Color = color.ToString();
                iphone.Price = price;
                iphone.AvailableQuantity = quantity;
                iphone.ScreenSize = screensize;
                iphone.UserID = userid;
                add.Add(iphone);
                add.SaveChanges();
                Console.WriteLine("iphone data added succesfully");

            }
        }

        public static void UpdateiphoneData()
        {
            var ctx = new InventoryContext();
            Iphone data = new Iphone();
            Console.Write("enter iphoneid: ");
            data.IPhoneID = Convert.ToInt32(Console.ReadLine());


            var finddata = ctx.iphones.First(x => x.IPhoneID == data.IPhoneID);

            Console.Write("enter available quantity: ");
            data.AvailableQuantity = Convert.ToInt32(Console.ReadLine());
            finddata.AvailableQuantity = data.AvailableQuantity;

            Console.WriteLine(ctx.SaveChanges());
        }
        public static void deleteiphonedata()
        {
            var ctx = new InventoryContext();
            Console.Write("enter  iphoneid: ");
            Iphone data = new Iphone();
            data.IPhoneID = Convert.ToInt32(Console.ReadLine());

            var finddata = ctx.iphones.First(x => x.IPhoneID == data.IPhoneID);
            ctx.iphones.Remove(finddata);
            Console.WriteLine(ctx.SaveChanges());
        }
        public static void FetchIphonedata()
        {
            var ctx = new InventoryContext();
            Iphone data = new Iphone();
            Console.WriteLine("Enter name : ");
            data.Name = Console.ReadLine();

            foreach (var item in ctx.iphones)
            {
                Console.WriteLine(item.IPhoneID + "|" + item.Name + "|" + item.Price + "|" + item.Color + "|" + item.AvailableQuantity + "|" + item.ScreenSize);
            }
        }
    }
}
