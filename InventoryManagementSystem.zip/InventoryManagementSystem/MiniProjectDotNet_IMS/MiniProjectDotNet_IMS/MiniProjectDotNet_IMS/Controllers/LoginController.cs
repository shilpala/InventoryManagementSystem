﻿using InventoryMangementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjectDotNet_IMS.Controllers
{
    public class LoginController
    {
        public static void Login()
        {
            InventoryContext IC = new InventoryContext();

            Console.Write("Enter Username: ");
            var username = Console.ReadLine();
            Console.Write("Enter password: ");
            var password = Console.ReadLine();
            Console.Write("Enter role: ");
            var role = Console.ReadLine();
            bool isfound = false;
            foreach (User user in IC.Users)
            {
                if (user.Username == username && user.Password == password && user.Role == role)
                {
                    isfound = true;
                    Console.WriteLine("login succesfully");


                }
                

            }
            if (isfound == false)
            {
                Console.WriteLine("Incorrect Credentials....");
            }
        }
    }
}
