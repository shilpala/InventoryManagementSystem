﻿using InventoryMangementSystem.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjectDotNet_IMS.Models
{
    public class Airpod
    {
        [Key]
        public int PodID { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Color { get; set; }
        [Required]
        public decimal Price { get; set; }
        [Required]
        public int AvailableQuantity { get; set; }
        [ForeignKey("UserID")]
        public int UserID { get; set; }
        public User users { get; set; }
    }
}
