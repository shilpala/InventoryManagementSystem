﻿using Microsoft.EntityFrameworkCore;
using MiniProjectDotNet_IMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryMangementSystem.Models
{
    class InventoryContext: DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server =SHILPALA-VD\\SQL2017; Database = Db_Project; user id=sa;password=cybage@123456");
            base.OnConfiguring(optionsBuilder);  
        }
     
        public DbSet<User> Users { get; set; }
        public DbSet<Iphone> iphones { get; set; }
        public DbSet<Airpod> airpods { get; set; }
        public DbSet<AppleIPad> appleipads { get; set; }
        public DbSet<Iwatch> iwatches { get; set; }



    }
}
