﻿using InventoryMangementSystem.Models;
using MiniProjectDotNet_IMS.Models;
using MiniProjectDotNet_IMS.Controllers;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace MiniProjectDotNet_IMS
{
    class Program
    {
        static void Main(string[] args)
        {
           // AddiphoneData();
            //FetchUser();
          //  AddUser();
            Console.WriteLine("Inventory Management System");
            int opt;
            Console.Write("menu driven program");
            Console.Write("\n\n");
            bool loopContinue;
            loopContinue = true;
            while (loopContinue)
            {
                Console.Write("Here are the options:");
                Console.Write("\n 1-Admin \n 2-User \n 3-Exit \n");
                
                Console.Write("Enter your choice: ");

              
                      
              
                opt = Convert.ToInt32(Console.ReadLine());
                //Console.BackgroundColor = ConsoleColor.Cyan;
                //Console.ForegroundColor = ConsoleColor.White;
                // Console.Clear();

                switch (opt)
                {
                    case 1:
                        bool loopWorking;
                        if (opt == 1)
                        {
                            LoginController.Login();

                           
                        }
                        else
                        {
                            Console.WriteLine("Please Give right Option.....");
                            
                        }
                        
                        
                        loopWorking = true;
                        while (loopWorking)
                        { label1 :
                          
                            Console.Write("\n 1-Add User \n 2-Delete User \n 3-Update User \n 4-Fetch User \n 5-IPhone \n 6-Airpod \n 7-AppleIPad \n 8-Iwatch \n 9.Exit\n");
                        int choice = Convert.ToInt32(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                AdminController.AddUser();
                                break;
                            case 2:
                                AdminController.deleteuser();
                                break;
                            case 3:
                                AdminController.UpdateUser();
                                break;
                            case 4:
                                AdminController.FetchUser();
                                break;
                            case 5:

                                    //  AddiphoneData();
                                    bool loopWorking2;
                                    loopWorking2 = true;
                                    while (loopWorking2)
                                    {
                                        Console.Write("\n 1-Add Iphone data \n 2-Delete Iphone data \n 3-Update Iphone data \n 4-Fetch Iphone data \n 5.Exit \n");
                                        int choice2 = Convert.ToInt32(Console.ReadLine());
                                        switch (choice2)
                                        {
                                            case 1:
                                                IphoneController.AddiphoneData();
                                                break;
                                            case 2:
                                                IphoneController.deleteiphonedata();
                                                break;
                                            case 3:
                                                IphoneController.UpdateiphoneData();
                                                break;
                                            case 4:
                                                IphoneController.FetchIphonedata();
                                                break;
                                            default:
                                                goto label1;


                                        }
                                    }
                                    break;
                            case 6:
                                //  deleteproduct();
                                        //  AddiphoneData();
                                    bool loopWorking3;
                                    loopWorking3 = true;
                                    while (loopWorking3)
                                    {
                                        Console.Write("\n 1-Add Airpod data \n 2-Delete Airpod data \n 3-Update Airpod data \n 4-Fetch Airpod data \n 5.Exit\n");
                                        int choice3 = Convert.ToInt32(Console.ReadLine());
                                        switch (choice3)
                                        {
                                            case 1:
                                                AirpodController.AddairpodData();
                                                break;
                                            case 2:
                                                AirpodController.deleteairpoddata();
                                                break;
                                            case 3:
                                                AirpodController.UpdateairpodData();
                                                break;
                                            case 4:
                                                AirpodController.Fetchairpoddata();
                                                break;
                                            default:
                                                System.Environment.Exit(0);
                                                break;



                                        }
                                    }
                                    break;
                                
                            case 7:
                                  
                                    
                                    bool loopWorking4;
                                    loopWorking4 = true;
                                    while (loopWorking4)
                                    { 
                                        Console.Write("\n 1-Add Apple Ipad data \n 2-Delete Apple Ipad  data \n 3-Update Apple Ipad  data \n 4-Fetch Apple Ipad  data \n 5-Exit \n");
                                        int choice4 = Convert.ToInt32(Console.ReadLine());
                                        switch (choice4)
                                        {
                                            case 1:
                                                AppleIpadController.AddappleipadData();
                                                break;
                                            case 2:
                                                AppleIpadController.deleteappleipaddata();
                                                break;
                                            case 3:
                                                AppleIpadController.UpdateappleipadData();
                                                break;
                                            case 4:
                                                AppleIpadController.Fetchappleipaddata();
                                                break;
                                            default:
                                                System.Environment.Exit(0);
                                                break;


                                        }
                                    }
                                    
                                    break;
                            case 8:
                                    bool loopWorking5;
                                    loopWorking5 = true;
                                    while (loopWorking5)
                                    { 
                                        Console.Write("\n 1-Add Iwatch data \n 2-Delete Iwatch  data \n 3-Update Iwatch  data \n 4-Fetch Iwatch  data \n");
                                        int choice5 = Convert.ToInt32(Console.ReadLine());
                                        switch (choice5)
                                        {
                                            case 1:
                                                IwatchController.AddIwatchData();
                                                break;
                                            case 2:
                                                IwatchController.DeleteIwatch();
                                                break;
                                            case 3:
                                                IwatchController.UpdateIwatchData();
                                                break;
                                            case 4:
                                                IwatchController.FetchIwatch();
                                                break;
                                            default:
                                                System.Environment.Exit(0);
                                                break;



                                        }
                                    }
                                    break;
                            
                            default:
                                Console.WriteLine("Please enter a valid choice.");
                                loopWorking = false;
                                break;
                        }

                }
                        break;
                    default:
                        Console.WriteLine("Please enter a valid choice.");
                        loopContinue = false;
                        break;
                }

            }
        }
       
       
    }
}
